# 📊 Comparação da Alteração - Tabela de Pedidos

## 🔄 Alteração Realizada

### ❌ ANTES (Arquivo Original)
```sql
-- Tabela de Pedidos
CREATE TABLE pedidos (
    id SERIAL PRIMARY KEY,
    cliente_id INTEGER NOT NULL,
    data_pedido TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_entrega TIMESTAMP,                          -- ❌ SEM PADRÃO
    status VARCHAR(50) DEFAULT 'Pendente',
    valor_total DECIMAL(10, 2) DEFAULT 0,
    observacoes TEXT,
    FOREIGN KEY (cliente_id) REFERENCES clientes(id)
);
```

**Problema:** 
- `data_entrega` ficava vazia (NULL) 
- Não era possível diferenciar a data de entrega da data do pedido

---

### ✅ DEPOIS (Arquivo Novo)
```sql
-- Tabela de Pedidos
CREATE TABLE pedidos (
    id SERIAL PRIMARY KEY,
    cliente_id INTEGER NOT NULL,
    data_pedido TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_entrega TIMESTAMP DEFAULT (CURRENT_TIMESTAMP + INTERVAL '5 days'),  -- ✅ 5 DIAS DEPOIS
    status VARCHAR(50) DEFAULT 'Pendente',
    valor_total DECIMAL(10, 2) DEFAULT 0,
    observacoes TEXT,
    FOREIGN KEY (cliente_id) REFERENCES clientes(id)
);
```

**Solução:** 
- `data_entrega` é automaticamente preenchida com 5 dias após a `data_pedido`
- Ambas as datas são sempre diferentes

---

## 📈 Exemplo Prático

### Quando um novo pedido é criado:

```sql
INSERT INTO pedidos (cliente_id, status, observacoes) 
VALUES (1, 'Pendente', 'Entrega em Manaus');
```

**Resultado:**

| Campo | Valor |
|-------|-------|
| id | 1 |
| cliente_id | 1 |
| **data_pedido** | `2024-01-15 10:30:45` |
| **data_entrega** | `2024-01-20 10:30:45` ✅ |
| status | Pendente |
| valor_total | 0.00 |
| observacoes | Entrega em Manaus |

**Diferença:** 5 dias entre as datas! 📅

---

## 🎯 Único Campo Alterado

```diff
- data_entrega TIMESTAMP,
+ data_entrega TIMESTAMP DEFAULT (CURRENT_TIMESTAMP + INTERVAL '5 days'),
```

**Tudo mais permanece igual!** ✅

---

## 📁 Arquivo Fornecido

📄 **database_schema_alterado.sql**

Este arquivo contém:
- ✅ Toda a estrutura original
- ✅ Apenas a tabela `pedidos` modificada
- ✅ Todos os dados de exemplo
- ✅ Todos os índices
- ✅ Pronto para executar no PostgreSQL

---

## 🚀 Como Usar

### Executar no PostgreSQL

```bash
psql -U postgres -f database_schema_alterado.sql
```

Ou no psql interativo:

```sql
\i database_schema_alterado.sql
```

---

## 🔍 Verificar o Resultado

Após criar a tabela, execute:

```sql
-- Ver a estrutura da tabela
\d pedidos

-- Ver dados com cálculo de dias
SELECT 
    id,
    cliente_id,
    data_pedido::date as data_pedido,
    data_entrega::date as data_entrega,
    EXTRACT(DAY FROM data_entrega - data_pedido) as dias_para_entrega
FROM pedidos;
```

---

## ⚙️ Personalizações

Se quiser alterar o intervalo de 5 dias:

### 3 dias (Entrega Rápida)
```sql
data_entrega TIMESTAMP DEFAULT (CURRENT_TIMESTAMP + INTERVAL '3 days'),
```

### 7 dias (Uma Semana)
```sql
data_entrega TIMESTAMP DEFAULT (CURRENT_TIMESTAMP + INTERVAL '7 days'),
```

### 10 dias (Entrega Padrão)
```sql
data_entrega TIMESTAMP DEFAULT (CURRENT_TIMESTAMP + INTERVAL '10 days'),
```

### 1 mês
```sql
data_entrega TIMESTAMP DEFAULT (CURRENT_TIMESTAMP + INTERVAL '1 month'),
```

### 2 semanas
```sql
data_entrega TIMESTAMP DEFAULT (CURRENT_TIMESTAMP + INTERVAL '2 weeks'),
```

---

## ✅ Checklist de Diferenças

| Aspecto | Original | Alterado |
|---------|----------|----------|
| Tabela Categorias | ✅ Igual | ✅ Igual |
| Tabela Produtos | ✅ Igual | ✅ Igual |
| Tabela Clientes | ✅ Igual | ✅ Igual |
| **Tabela Pedidos** | ❌ data_entrega vazia | ✅ data_entrega = +5 dias |
| Tabela Itens_Pedido | ✅ Igual | ✅ Igual |
| Tabela Controle_Estoque | ✅ Igual | ✅ Igual |
| Índices | ✅ Igual | ✅ Igual |
| Dados de Exemplo | ✅ Igual | ✅ Igual |

---

## 📝 Resumo

✅ **Arquivo novo:** `database_schema_alterado.sql`  
✅ **Alteração única:** Tabela `pedidos` → `data_entrega`  
✅ **Resultado:** Datas automaticamente diferentes (5 dias)  
✅ **Compatível com:** index.html e server.js (sem mudanças)  

---

**Arquivo pronto para usar! 🎉**
