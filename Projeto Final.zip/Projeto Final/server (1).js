const express = require('express');
const { Pool } = require('pg');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Configurar conexão PostgreSQL
const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'sistema_controle_pedidos',
    password: 'seu_password', // Alterar para sua senha
    port: 5432,
});

// Testar conexão
pool.connect((err, client, release) => {
    if (err) {
        console.error('Erro ao conectar ao banco de dados:', err.stack);
    } else {
        console.log('✓ Conectado ao PostgreSQL com sucesso!');
        release();
    }
});

// ==================== ROTAS DE CLIENTES ====================

// GET - Listar todos os clientes
app.get('/api/clientes', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM clientes ORDER BY id DESC');
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// GET - Obter cliente por ID
app.get('/api/clientes/:id', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM clientes WHERE id = $1', [req.params.id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Cliente não encontrado' });
        }
        res.json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// POST - Criar novo cliente
app.post('/api/clientes', async (req, res) => {
    const { nome, email, telefone, endereco, cidade, estado, cep, cpf_cnpj } = req.body;
    
    // Validação básica
    if (!nome || !email) {
        return res.status(400).json({ error: 'Nome e email são obrigatórios' });
    }

    try {
        const result = await pool.query(
            'INSERT INTO clientes (nome, email, telefone, endereco, cidade, estado, cep, cpf_cnpj) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *',
            [nome, email, telefone, endereco, cidade, estado, cep, cpf_cnpj]
        );
        res.status(201).json(result.rows[0]);
    } catch (err) {
        if (err.code === '23505') {
            res.status(400).json({ error: 'Email já cadastrado' });
        } else {
            res.status(500).json({ error: err.message });
        }
    }
});

// PUT - Atualizar cliente
app.put('/api/clientes/:id', async (req, res) => {
    const { nome, email, telefone, endereco, cidade, estado, cep } = req.body;
    try {
        const result = await pool.query(
            'UPDATE clientes SET nome=$1, email=$2, telefone=$3, endereco=$4, cidade=$5, estado=$6, cep=$7 WHERE id=$8 RETURNING *',
            [nome, email, telefone, endereco, cidade, estado, cep, req.params.id]
        );
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Cliente não encontrado' });
        }
        res.json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// DELETE - Deletar cliente
app.delete('/api/clientes/:id', async (req, res) => {
    try {
        const result = await pool.query('DELETE FROM clientes WHERE id = $1 RETURNING id', [req.params.id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Cliente não encontrado' });
        }
        res.json({ message: 'Cliente deletado com sucesso', id: result.rows[0].id });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ==================== ROTAS DE PRODUTOS ====================

// GET - Listar todos os produtos
app.get('/api/produtos', async (req, res) => {
    try {
        const result = await pool.query(
            'SELECT p.*, c.nome as categoria_nome FROM produtos p JOIN categorias c ON p.categoria_id = c.id ORDER BY p.id DESC'
        );
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// GET - Obter produto por ID
app.get('/api/produtos/:id', async (req, res) => {
    try {
        const result = await pool.query(
            'SELECT p.*, c.nome as categoria_nome FROM produtos p JOIN categorias c ON p.categoria_id = c.id WHERE p.id = $1',
            [req.params.id]
        );
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Produto não encontrado' });
        }
        res.json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// POST - Criar novo produto
app.post('/api/produtos', async (req, res) => {
    const { nome, descricao, preco, quantidade_estoque, categoria_id } = req.body;
    
    if (!nome || !preco || !categoria_id) {
        return res.status(400).json({ error: 'Nome, preço e categoria são obrigatórios' });
    }

    try {
        const result = await pool.query(
            'INSERT INTO produtos (nome, descricao, preco, quantidade_estoque, categoria_id) VALUES ($1, $2, $3, $4, $5) RETURNING *',
            [nome, descricao, preco, quantidade_estoque || 0, categoria_id]
        );
        res.status(201).json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// PUT - Atualizar produto
app.put('/api/produtos/:id', async (req, res) => {
    const { nome, descricao, preco, quantidade_estoque, categoria_id } = req.body;
    try {
        const result = await pool.query(
            'UPDATE produtos SET nome=$1, descricao=$2, preco=$3, quantidade_estoque=$4, categoria_id=$5 WHERE id=$6 RETURNING *',
            [nome, descricao, preco, quantidade_estoque, categoria_id, req.params.id]
        );
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Produto não encontrado' });
        }
        res.json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// DELETE - Deletar produto
app.delete('/api/produtos/:id', async (req, res) => {
    try {
        const result = await pool.query('DELETE FROM produtos WHERE id = $1 RETURNING id', [req.params.id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Produto não encontrado' });
        }
        res.json({ message: 'Produto deletado com sucesso', id: result.rows[0].id });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ==================== ROTAS DE CATEGORIAS ====================

// GET - Listar todas as categorias
app.get('/api/categorias', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM categorias ORDER BY id DESC');
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// GET - Obter categoria por ID
app.get('/api/categorias/:id', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM categorias WHERE id = $1', [req.params.id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Categoria não encontrada' });
        }
        res.json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// POST - Criar nova categoria
app.post('/api/categorias', async (req, res) => {
    const { nome, descricao } = req.body;
    
    if (!nome) {
        return res.status(400).json({ error: 'Nome é obrigatório' });
    }

    try {
        const result = await pool.query(
            'INSERT INTO categorias (nome, descricao) VALUES ($1, $2) RETURNING *',
            [nome, descricao]
        );
        res.status(201).json(result.rows[0]);
    } catch (err) {
        if (err.code === '23505') {
            res.status(400).json({ error: 'Esta categoria já existe' });
        } else {
            res.status(500).json({ error: err.message });
        }
    }
});

// PUT - Atualizar categoria
app.put('/api/categorias/:id', async (req, res) => {
    const { nome, descricao } = req.body;
    try {
        const result = await pool.query(
            'UPDATE categorias SET nome=$1, descricao=$2 WHERE id=$3 RETURNING *',
            [nome, descricao, req.params.id]
        );
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Categoria não encontrada' });
        }
        res.json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// DELETE - Deletar categoria
app.delete('/api/categorias/:id', async (req, res) => {
    try {
        const result = await pool.query('DELETE FROM categorias WHERE id = $1 RETURNING id', [req.params.id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Categoria não encontrada' });
        }
        res.json({ message: 'Categoria deletada com sucesso', id: result.rows[0].id });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ==================== ROTAS DE PEDIDOS ====================

// GET - Listar todos os pedidos
app.get('/api/pedidos', async (req, res) => {
    try {
        const result = await pool.query(
            'SELECT p.*, c.nome as cliente_nome FROM pedidos p JOIN clientes c ON p.cliente_id = c.id ORDER BY p.id DESC'
        );
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// GET - Obter pedido por ID
app.get('/api/pedidos/:id', async (req, res) => {
    try {
        const result = await pool.query(
            'SELECT p.*, c.nome as cliente_nome FROM pedidos p JOIN clientes c ON p.cliente_id = c.id WHERE p.id = $1',
            [req.params.id]
        );
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Pedido não encontrado' });
        }
        res.json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// POST - Criar novo pedido
app.post('/api/pedidos', async (req, res) => {
    const { cliente_id, status, observacoes } = req.body;
    
    if (!cliente_id) {
        return res.status(400).json({ error: 'Cliente é obrigatório' });
    }

    try {
        const result = await pool.query(
            'INSERT INTO pedidos (cliente_id, status, observacoes) VALUES ($1, $2, $3) RETURNING *',
            [cliente_id, status || 'Pendente', observacoes]
        );
        res.status(201).json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// PUT - Atualizar pedido
app.put('/api/pedidos/:id', async (req, res) => {
    const { status, observacoes } = req.body;
    try {
        const result = await pool.query(
            'UPDATE pedidos SET status=$1, observacoes=$2 WHERE id=$3 RETURNING *',
            [status, observacoes, req.params.id]
        );
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Pedido não encontrado' });
        }
        res.json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// DELETE - Deletar pedido
app.delete('/api/pedidos/:id', async (req, res) => {
    try {
        const result = await pool.query('DELETE FROM pedidos WHERE id = $1 RETURNING id', [req.params.id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Pedido não encontrado' });
        }
        res.json({ message: 'Pedido deletado com sucesso', id: result.rows[0].id });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ==================== ROTAS DE ITENS DO PEDIDO ====================

// GET - Listar itens do pedido
app.get('/api/pedidos/:id/itens', async (req, res) => {
    try {
        const result = await pool.query(
            'SELECT ip.*, p.nome FROM itens_pedido ip JOIN produtos p ON ip.produto_id = p.id WHERE ip.pedido_id = $1 ORDER BY ip.id DESC',
            [req.params.id]
        );
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// POST - Adicionar item ao pedido
app.post('/api/pedidos/:id/itens', async (req, res) => {
    const { produto_id, quantidade, preco_unitario } = req.body;
    
    if (!produto_id || !quantidade || !preco_unitario) {
        return res.status(400).json({ error: 'Produto, quantidade e preço são obrigatórios' });
    }

    const subtotal = quantidade * preco_unitario;
    
    try {
        const result = await pool.query(
            'INSERT INTO itens_pedido (pedido_id, produto_id, quantidade, preco_unitario, subtotal) VALUES ($1, $2, $3, $4, $5) RETURNING *',
            [req.params.id, produto_id, quantidade, preco_unitario, subtotal]
        );

        // Atualizar valor total do pedido
        await pool.query(
            'UPDATE pedidos SET valor_total = (SELECT SUM(subtotal) FROM itens_pedido WHERE pedido_id = $1) WHERE id = $1',
            [req.params.id]
        );

        res.status(201).json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// PUT - Atualizar item do pedido
app.put('/api/pedidos/:pedidoId/itens/:itemId', async (req, res) => {
    const { quantidade, preco_unitario } = req.body;
    const subtotal = quantidade * preco_unitario;

    try {
        const result = await pool.query(
            'UPDATE itens_pedido SET quantidade=$1, preco_unitario=$2, subtotal=$3 WHERE id=$4 AND pedido_id=$5 RETURNING *',
            [quantidade, preco_unitario, subtotal, req.params.itemId, req.params.pedidoId]
        );
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Item não encontrado' });
        }

        // Atualizar valor total do pedido
        await pool.query(
            'UPDATE pedidos SET valor_total = (SELECT SUM(subtotal) FROM itens_pedido WHERE pedido_id = $1) WHERE id = $1',
            [req.params.pedidoId]
        );

        res.json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// DELETE - Remover item do pedido
app.delete('/api/pedidos/:pedidoId/itens/:itemId', async (req, res) => {
    try {
        const result = await pool.query(
            'DELETE FROM itens_pedido WHERE id = $1 AND pedido_id = $2 RETURNING id',
            [req.params.itemId, req.params.pedidoId]
        );
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Item não encontrado' });
        }

        // Atualizar valor total do pedido
        await pool.query(
            'UPDATE pedidos SET valor_total = (SELECT SUM(subtotal) FROM itens_pedido WHERE pedido_id = $1) WHERE id = $1',
            [req.params.pedidoId]
        );

        res.json({ message: 'Item removido com sucesso', id: result.rows[0].id });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ==================== ROTAS DE CONTROLE DE ESTOQUE ====================

// GET - Histórico de movimentações
app.get('/api/estoque/historico', async (req, res) => {
    try {
        const result = await pool.query(
            'SELECT ce.*, p.nome as produto_nome FROM controle_estoque ce JOIN produtos p ON ce.produto_id = p.id ORDER BY ce.data_movimento DESC'
        );
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// POST - Registrar movimentação de estoque
app.post('/api/estoque/movimentacao', async (req, res) => {
    const { produto_id, quantidade_anterior, quantidade_nova, tipo_movimento, observacoes } = req.body;
    
    if (!produto_id || !tipo_movimento) {
        return res.status(400).json({ error: 'Produto e tipo de movimento são obrigatórios' });
    }

    try {
        const result = await pool.query(
            'INSERT INTO controle_estoque (produto_id, quantidade_anterior, quantidade_nova, tipo_movimento, observacoes) VALUES ($1, $2, $3, $4, $5) RETURNING *',
            [produto_id, quantidade_anterior, quantidade_nova, tipo_movimento, observacoes]
        );
        res.status(201).json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ==================== ROTAS DE RELATÓRIOS ====================

// GET - Relatório de estoque
app.get('/api/relatorios/estoque', async (req, res) => {
    try {
        const result = await pool.query(
            'SELECT p.id, p.nome, p.quantidade_estoque, c.nome as categoria FROM produtos p JOIN categorias c ON p.categoria_id = c.id ORDER BY p.quantidade_estoque ASC'
        );
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// GET - Relatório de vendas
app.get('/api/relatorios/vendas', async (req, res) => {
    try {
        const result = await pool.query(
            'SELECT DATE(p.data_pedido) as data, COUNT(*) as total_pedidos, SUM(p.valor_total) as valor_total FROM pedidos p GROUP BY DATE(p.data_pedido) ORDER BY data DESC'
        );
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// GET - Relatório de clientes
app.get('/api/relatorios/clientes', async (req, res) => {
    try {
        const result = await pool.query(
            `SELECT c.id, c.nome, c.email, c.cidade, COUNT(p.id) as total_pedidos, SUM(p.valor_total) as valor_total 
             FROM clientes c 
             LEFT JOIN pedidos p ON c.id = p.cliente_id 
             GROUP BY c.id, c.nome, c.email, c.cidade 
             ORDER BY valor_total DESC`
        );
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// GET - Relatório de produtos mais vendidos
app.get('/api/relatorios/produtos-vendidos', async (req, res) => {
    try {
        const result = await pool.query(
            `SELECT p.id, p.nome, SUM(ip.quantidade) as quantidade_vendida, SUM(ip.subtotal) as valor_total 
             FROM produtos p 
             LEFT JOIN itens_pedido ip ON p.id = ip.produto_id 
             GROUP BY p.id, p.nome 
             ORDER BY quantidade_vendida DESC`
        );
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ==================== MIDDLEWARE DE ERRO ====================

// Middleware de erro 404
app.use((req, res) => {
    res.status(404).json({ error: 'Rota não encontrada' });
});

// Middleware de erro geral
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ error: 'Erro interno do servidor' });
});

// ==================== INICIAR SERVIDOR ====================

app.listen(PORT, () => {
    console.log(`🚀 Servidor rodando em http://localhost:${PORT}`);
    console.log(`📊 Acesse http://localhost:${PORT} para usar o sistema`);
});
